<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0x10 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0x20 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0x30 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0x40 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0x50 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0x60 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0x70 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0x80 => 'you', 'chang', 'ya', 'yin', 'ya', 'ren', 'jiong', NULL, 'dao', 'dao', 'bo', 'jie', 'xiao', 'xiao', 'wu', 'wang',
  0x90 => 'wang', 'wu', 'si', 'yao', 'ji', 'ji', 'xin', 'xin', 'shou', 'sui', NULL, 'ri', 'ri', 'yue', 'dai', 'mu',
  0xA0 => 'min', 'shui', 'shui', 'biao', 'zhao', 'zhao', 'qiang', 'niu', 'quan', NULL, NULL, 'mu', 'shi', 'shi', 'shi', 'si',
  0xB0 => 'si', 'gang', 'wang', NULL, 'wang', NULL, 'ren', 'ren', NULL, NULL, 'yu', 'yu', 'rou', 'ju', 'cao', 'cao',
  0xC0 => 'cao', 'hu', 'yi', 'xi', 'xi', 'jian', NULL, NULL, 'yan', 'bei', NULL, 'che', 'chuo', 'chuo', 'chuo', 'fu',
  0xD0 => 'jin', 'chang', 'chang', 'zhang', 'men', NULL, 'fu', 'yu', 'qing', 'wei', 'ye', 'feng', 'fei', 'shi', NULL, 'shi',
  0xE0 => 'shi', NULL, 'ma', 'gu', 'gui', 'yu', 'niao', 'lu', 'mai', 'huang', 'mian', 'qi', 'qi', 'chi', 'chi', 'long',
  0xF0 => 'long', 'gui', 'gui', 'gui', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
];
